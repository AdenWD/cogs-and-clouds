Cinder Biome Removal 1.21.1

Requires Biolith 3.x.

This datapack removes the listed biomes from Overworld biome placement. It does not replace them with Forest or another biome.

Install:
1. Put this ZIP in <world>/datapacks/
2. Load the world.
3. Run /datapack list to confirm it is enabled.
4. Generate NEW chunks/worlds to test generation.

Existing generated chunks are not retroactively changed.
