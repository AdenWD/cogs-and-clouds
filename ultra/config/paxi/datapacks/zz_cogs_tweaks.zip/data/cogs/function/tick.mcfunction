# --- Naturalist bird on head: its client-side glide never resets server fall distance -> landing damage.
tag @a[tag=cogs.bird] remove cogs.bird
execute as @e[type=naturalist:bird] on vehicle if entity @s[type=minecraft:player] run tag @s add cogs.bird
execute as @a[tag=cogs.bird] run attribute @s minecraft:generic.safe_fall_distance modifier add cogs:bird_glide 4096 add_value
execute as @a[tag=!cogs.bird,tag=cogs.glide,nbt={OnGround:1b}] run function cogs:glide_off
tag @a[tag=cogs.bird] add cogs.glide
# --- Longer days / shorter nights (only while the daylight cycle is running)
execute store result score #dl cogs.time run gamerule doDaylightCycle
execute if score #dl cogs.time matches 1 run function cogs:time/step
