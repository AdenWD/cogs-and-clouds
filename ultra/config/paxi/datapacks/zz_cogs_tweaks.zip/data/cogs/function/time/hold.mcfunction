execute store result score #d cogs.time run time query day
scoreboard players operation #d cogs.time *= #24000 cogs.time
scoreboard players operation #d cogs.time += #t cogs.time
scoreboard players remove #d cogs.time 1
execute store result storage cogs:time v int 1 run scoreboard players get #d cogs.time
function cogs:time/set with storage cogs:time
