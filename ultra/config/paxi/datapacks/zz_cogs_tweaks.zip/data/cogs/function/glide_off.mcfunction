attribute @s minecraft:generic.safe_fall_distance modifier remove cogs:bird_glide
tag @s remove cogs.glide
