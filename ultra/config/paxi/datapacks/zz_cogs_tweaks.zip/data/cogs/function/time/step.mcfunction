# Day (0-11999): time holds every other tick -> 2x longer (20 min).
# Night (12000-23999) runs at normal speed -> 10 min from sunset to sunrise (Aden, 2026-11-18).
# Dusk/dawn ticks (e.g. Emma's World concert start at 13000) are never skipped.
execute store result score #t cogs.time run time query daytime
execute if score #t cogs.time matches 1..11999 store result score #g cogs.time run time query gametime
execute if score #t cogs.time matches 1..11999 run scoreboard players operation #g cogs.time %= #2 cogs.time
execute if score #t cogs.time matches 1..11999 if score #g cogs.time matches 0 run function cogs:time/hold
