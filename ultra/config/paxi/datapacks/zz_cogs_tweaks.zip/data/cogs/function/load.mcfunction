scoreboard objectives add cogs.time dummy
scoreboard players set #2 cogs.time 2
scoreboard players set #24000 cogs.time 24000
